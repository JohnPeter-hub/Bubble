from django.contrib import admin
from . models import RegisterUsers

# Register your models here.
admin.site.register(RegisterUsers)